import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

const RENDER_BASE = 'https://viajesperdomos.onrender.com';

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// ==========================================
// ENDPOINT: DESCARGAR CÓDIGO FUENTE EN ARCHIVO .ZIP FOR GITHUB
// ==========================================
app.get('/api/download-zip', (_req, res) => {
  try {
    const zipPath = '/tmp/viajes-perdomo-proyecto.zip';
    if (fs.existsSync(zipPath)) {
      fs.unlinkSync(zipPath);
    }

    const pyScript = `import zipfile, os
zip_path = '${zipPath}'
if os.path.exists(zip_path):
    os.remove(zip_path)
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in ['node_modules', '.git', 'dist', '.aistudio', '.cache']]
        for file in files:
            if file.endswith('.zip') or file == 'server-data.json':
                continue
            full_path = os.path.join(root, file)
            arc_name = os.path.relpath(full_path, '.')
            z.write(full_path, arc_name)
`;
    execSync(`python3 -c "${pyScript.replace(/"/g, '\\"')}"`, { cwd: path.resolve(__dirname) });

    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', 'attachment; filename="viajes-perdomo-proyecto.zip"');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    return res.sendFile(zipPath);
  } catch (err: any) {
    console.error('Error generando zip del proyecto:', err);
    return res.status(500).json({ error: 'Error al generar archivo ZIP del proyecto' });
  }
});

// ==========================================
// PROXY ALL OTHER /api/* REQUESTS TO REAL RENDER BACKEND
// ==========================================
app.use('/api', async (req, res) => {
  try {
    const targetUrl = `${RENDER_BASE}/api${req.url}`;
    const headers: Record<string, string> = {};
    
    if (req.headers['content-type']) {
      headers['content-type'] = req.headers['content-type'] as string;
    } else if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
      headers['content-type'] = 'application/json';
    }

    const fetchOptions: RequestInit = {
      method: req.method,
      headers,
    };

    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && req.body && Object.keys(req.body).length > 0) {
      fetchOptions.body = JSON.stringify(req.body);
    }

    const response = await fetch(targetUrl, fetchOptions);
    const contentType = response.headers.get('content-type') || '';

    res.status(response.status);

    if (contentType.includes('application/json')) {
      const data = await response.json();
      res.json(data);
    } else {
      const text = await response.text();
      res.send(text);
    }
  } catch (err: any) {
    console.error('Error proxying to Render backend:', err);
    res.status(502).json({ error: 'Error al conectar con el servidor de Render', details: err.message });
  }
});

// ==========================================
// VITE DEV MIDDLEWARE / STATIC ASSETS
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT} -> proxying /api to ${RENDER_BASE}`);
  });
}

startServer();
