/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';

// Declaración global para Html5Qrcode
declare global {
  interface Window {
    Html5Qrcode: any;
    webkitAudioContext: typeof AudioContext;
  }
}

const RENDER_BASE_URL = 'https://viajesperdomos.onrender.com';

const getApiUrl = (endpoint: string): string => {
  if (!endpoint || typeof endpoint !== 'string') return endpoint;
  if (!endpoint.startsWith('/api') && !endpoint.startsWith('api')) return endpoint;
  if (endpoint.includes('download-zip')) return endpoint;

  const isCapacitorOrAPK =
    typeof window !== 'undefined' &&
    (Boolean((window as any).Capacitor) ||
      window.location.protocol === 'capacitor:' ||
      window.location.protocol === 'file:' ||
      Boolean(window.location.hostname === 'localhost' && (window as any).Capacitor));

  if (isCapacitorOrAPK) {
    const cleanPath = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
    return `${RENDER_BASE_URL}${cleanPath}`;
  }

  return endpoint;
};

const apiFetch = (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
  const urlStr = typeof input === 'string' ? input : input instanceof URL ? input.toString() : (input as Request).url;
  const resolvedUrl = getApiUrl(urlStr);
  if (input instanceof Request && resolvedUrl !== input.url) {
    return fetch(new Request(resolvedUrl, input), init);
  }
  return fetch(resolvedUrl, init);
};

interface Guagua {
  id: string;
  placa?: string;
  origen: string;
  destino: string;
  precio: number;
  moneda: string;
  salida: string;
  duracion: number;
  asientos: number;
  asientosDisp: number;
  estado: string;
  motivoTaller?: string;
  fecha?: string;
  imagen?: string | null;
}

interface Reserva {
  id: string;
  codigo: string;
  guaguaId: string;
  nombre: string;
  email?: string;
  telefono?: string;
  fechaViaje: string;
  cantidad: number;
  total: number;
  moneda: string;
  gestorCodigo?: string;
  estado: 'pendiente' | 'confirmada' | 'cancelada' | 'completada' | 'cancelada_admin';
}

interface Credencial {
  id: string;
  nombre: string;
  usuario: string;
  password?: string;
  rol: 'admin' | 'gestor';
}

interface Usuario {
  id: string;
  nombre: string;
  email: string;
  password?: string;
  gestorCodigo?: string;
}

interface Chofer {
  id: string;
  nombre: string;
  carnet: string;
  telefono: string;
  guaguaId: string;
  rutaAsignada: string;
  estado: 'trabajando' | 'descanso' | 'vacaciones' | 'enfermo' | 'en_ruta';
  foto?: string | null;
}

interface Notificacion {
  id: string;
  tipo: 'alerta_critica' | 'reserva_afectada' | 'info';
  mensaje: string;
  leida: boolean;
  fecha: string;
  cliente?: string;
  email?: string;
  codigoReserva?: string;
  informada?: boolean;
  guaguaId?: string;
  requiereAccion?: boolean;
}

interface Valoracion {
  id: string;
  guaguaId?: string;
  estrellas: number;
  comentario: string;
  autor: string;
  fecha?: string;
}

interface Estadisticas {
  totalVendidos: number;
  cancelados: number;
  canceladosAdmin: number;
  completados: number;
  pendientes: number;
  dineroCUP: number;
  dineroMLC: number;
  totalReservas?: number;
  reservasPendientes?: number;
  reservasConfirmadas?: number;
  reservasCompletadas?: number;
  reservasCanceladas?: number;
  gananciasCUP?: number;
  gananciasMLC?: number;
  totalPasajeros?: number;
  guaguasActivas?: number;
  guaguasTaller?: number;
  guaguasRuta?: number;
  totalGuaguas?: number;
  totalClientes?: number;
  totalChoferes?: number;
}

export default function App() {
  // Estado de Autenticación y Layout
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [loginUser, setLoginUser] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [activeView, setActiveView] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Datos del Servidor
  const [guaguas, setGuaguas] = useState<Guagua[]>([]);
  const [reservas, setReservas] = useState<Reserva[]>([]);
  const [credenciales, setCredenciales] = useState<Credencial[]>([]);
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [origenes, setOrigenes] = useState<string[]>([]);
  const [destinos, setDestinos] = useState<string[]>([]);
  const [choferes, setChoferes] = useState<Chofer[]>([]);
  const [notificaciones, setNotificaciones] = useState<Notificacion[]>([]);
  const [pwaConfig, setPwaConfig] = useState({ heroTitulo: '', heroSubtitulo: '' });
  const [gestores, setGestores] = useState<{ id: string; nombre: string; usuario: string; rol: string }[]>([]);
  const [valoraciones, setValoraciones] = useState<Valoracion[]>([]);
  const [estadisticas, setEstadisticas] = useState<Estadisticas>({
    totalVendidos: 0,
    cancelados: 0,
    canceladosAdmin: 0,
    completados: 0,
    pendientes: 0,
    dineroCUP: 0,
    dineroMLC: 0,
  });

  // Inputs de Rutas
  const [nuevoOrigen, setNuevoOrigen] = useState('');
  const [nuevoDestino, setNuevoDestino] = useState('');

  // Filtros
  const [filtroEstadoGuagua, setFiltroEstadoGuagua] = useState('');
  const [filtroChoferGuagua, setFiltroChoferGuagua] = useState('');
  const [filtroRutaGuagua, setFiltroRutaGuagua] = useState('');
  const [filtroFechaGuagua, setFiltroFechaGuagua] = useState('');
  const [filtroFechaReserva, setFiltroFechaReserva] = useState('');

  // Modales
  const [modalGuaguaOpen, setModalGuaguaOpen] = useState(false);
  const [modalChoferOpen, setModalChoferOpen] = useState(false);
  const [modalClienteOpen, setModalClienteOpen] = useState(false);
  const [modalCredencialOpen, setModalCredencialOpen] = useState(false);

  // Formulario Guagua
  const [gId, setGId] = useState('');
  const [gPlaca, setGPlaca] = useState('');
  const [gOrigen, setGOrigen] = useState('');
  const [gDestino, setGDestino] = useState('');
  const [gPrecio, setGPrecio] = useState(1000);
  const [gMoneda, setGMoneda] = useState('CUP');
  const [gSalida, setGSalida] = useState('08:00');
  const [gDuracion, setGDuracion] = useState(2);
  const [gAsientos, setGAsientos] = useState(40);
  const [gEstado, setGEstado] = useState('funcionamiento');
  const [gMotivoTaller, setGMotivoTaller] = useState('');
  const [gTipoProgramacion, setGTipoProgramacion] = useState<'unico' | 'recurrente'>('unico');
  const [gFechasUnicas, setGFechasUnicas] = useState('');
  const [gDiasRecurrentes, setGDiasRecurrentes] = useState<number[]>([]);
  const [fotoGuaguaBase64, setFotoGuaguaBase64] = useState<string | null>(null);

  // Formulario Chofer
  const [cId, setCId] = useState('');
  const [cNombre, setCNombre] = useState('');
  const [cCarnet, setCCarnet] = useState('');
  const [cTelefono, setCTelefono] = useState('');
  const [cTipoAsignacion, setCTipoAsignacion] = useState('ninguna');
  const [cSelectRuta, setCSelectRuta] = useState('');
  const [cSelectGuaguaRuta, setCSelectGuaguaRuta] = useState('');
  const [cSelectGuagua, setCSelectGuagua] = useState('');
  const [cSelectRutaGuagua, setCSelectRutaGuagua] = useState('');
  const [cEstado, setCEstado] = useState<'trabajando' | 'descanso' | 'vacaciones' | 'enfermo' | 'en_ruta'>('trabajando');
  const [fotoChoferBase64, setFotoChoferBase64] = useState<string | null>(null);

  // Formulario Cliente
  const [cliId, setCliId] = useState('');
  const [cliNombre, setCliNombre] = useState('');
  const [cliEmail, setCliEmail] = useState('');
  const [cliPassword, setCliPassword] = useState('');
  const [cliGestor, setCliGestor] = useState('');

  // Formulario Staff (Credencial)
  const [credId, setCredId] = useState('');
  const [credNombre, setCredNombre] = useState('');
  const [credUsuario, setCredUsuario] = useState('');
  const [credPassword, setCredPassword] = useState('');
  const [credRol, setCredRol] = useState<'gestor' | 'admin'>('gestor');

  // Escáner QR
  const [qrResultado, setQrResultado] = useState<{
    valida: boolean;
    reserva?: Reserva;
    mensaje?: string;
  } | null>(null);
  const [manualCode, setManualCode] = useState('');
  const html5QrCodeRef = useRef<any>(null);

  // Audio Context
  const audioCtxRef = useRef<AudioContext | null>(null);
  const audioIntervalRef = useRef<any>(null);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) audioCtxRef.current = new AudioCtx();
    }
  };

  const reproducirSonido = () => {
    try {
      initAudio();
      if (!audioCtxRef.current) return;
      if (audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }
      const osc = audioCtxRef.current.createOscillator();
      const gain = audioCtxRef.current.createGain();
      osc.connect(gain);
      gain.connect(audioCtxRef.current.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtxRef.current.currentTime);
      gain.gain.setValueAtTime(0.1, audioCtxRef.current.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtxRef.current.currentTime + 0.5);
      osc.start();
      osc.stop(audioCtxRef.current.currentTime + 0.5);
    } catch (e) {
      console.warn('Audio error:', e);
    }
  };

  // Carga Global de Datos del Servidor
  const cargarTodo = async () => {
    try {
      const [rG, rR, rC, rU, rO, rD, rCh, rN, rP, rGest, rEst, rVal] = await Promise.all([
        apiFetch('/api/guaguas'),
        apiFetch('/api/reservas'),
        apiFetch('/api/credenciales'),
        apiFetch('/api/usuarios'),
        apiFetch('/api/origenes'),
        apiFetch('/api/destinos'),
        apiFetch('/api/choferes'),
        apiFetch('/api/notificaciones'),
        apiFetch('/api/config'),
        apiFetch('/api/gestores'),
        apiFetch('/api/estadisticas'),
        apiFetch('/api/valoraciones'),
      ]);

      const [dG, dR, dC, dU, dO, dD, dCh, dN, dP, dGest, dEst, dVal] = await Promise.all([
        rG.json(),
        rR.json(),
        rC.json(),
        rU.json(),
        rO.json(),
        rD.json(),
        rCh.json(),
        rN.json(),
        rP.json(),
        rGest.json(),
        rEst.json(),
        rVal.json(),
      ]);

      setGuaguas(Array.isArray(dG) ? dG : []);
      setReservas(Array.isArray(dR) ? dR : []);
      setCredenciales(Array.isArray(dC) ? dC : []);
      setUsuarios(Array.isArray(dU) ? dU : []);
      setOrigenes(Array.isArray(dO) ? dO : []);
      setDestinos(Array.isArray(dD) ? dD : []);
      setChoferes(Array.isArray(dCh) ? dCh : []);
      setNotificaciones(Array.isArray(dN) ? dN : []);
      if (dP) setPwaConfig(dP);
      setGestores(Array.isArray(dGest) ? dGest : []);
      if (dEst) {
        setEstadisticas({
          totalVendidos: dEst.totalVendidos ?? dEst.totalReservas ?? 0,
          cancelados: dEst.cancelados ?? 0,
          canceladosAdmin: dEst.canceladosAdmin ?? 0,
          completados: dEst.completados ?? dEst.reservasCompletadas ?? 0,
          pendientes: dEst.pendientes ?? dEst.reservasPendientes ?? 0,
          dineroCUP: dEst.dineroCUP ?? dEst.gananciasCUP ?? 0,
          dineroMLC: dEst.dineroMLC ?? dEst.gananciasMLC ?? 0,
          totalReservas: dEst.totalVendidos ?? dEst.totalReservas ?? 0,
          reservasPendientes: dEst.pendientes ?? dEst.reservasPendientes ?? 0,
          reservasConfirmadas: dEst.confirmados ?? dEst.reservasConfirmadas ?? 0,
          reservasCompletadas: dEst.completados ?? dEst.reservasCompletadas ?? 0,
          reservasCanceladas: (dEst.cancelados || 0) + (dEst.canceladosAdmin || 0) || (dEst.reservasCanceladas || 0),
          gananciasCUP: dEst.dineroCUP ?? dEst.gananciasCUP ?? 0,
          gananciasMLC: dEst.dineroMLC ?? dEst.gananciasMLC ?? 0,
          totalPasajeros: dEst.totalPasajeros ?? 0,
          guaguasActivas: dEst.guaguasActivas ?? 0,
          guaguasTaller: dEst.guaguasTaller ?? 0,
          guaguasRuta: dEst.guaguasRuta ?? 0,
          totalGuaguas: dEst.totalGuaguas ?? 0,
          totalClientes: dEst.totalClientes ?? 0,
          totalChoferes: dEst.totalChoferes ?? 0,
        });
      }
      setValoraciones(Array.isArray(dVal) ? dVal : []);
    } catch (error) {
      console.error('Error cargando datos del servidor:', error);
    }
  };

  // Chequeo de Notificaciones y sonido periódico
  useEffect(() => {
    if (!isLoggedIn) return;
    const noLeidas = notificaciones.filter((n) => !n.leida);
    if (noLeidas.length > 0) {
      if (!audioIntervalRef.current) {
        reproducirSonido();
        audioIntervalRef.current = setInterval(reproducirSonido, 300000); // 5 minutos
      }
    } else {
      if (audioIntervalRef.current) {
        clearInterval(audioIntervalRef.current);
        audioIntervalRef.current = null;
      }
    }
  }, [notificaciones, isLoggedIn]);

  // Manejo de Login (conecta al servidor Render /api/auth/login y /api/credenciales)
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loginUser === 'admin' && loginPass === 'admin123') {
      setCurrentUser({ usuario: 'admin', nombre: 'Administrador', rol: 'admin' });
      setIsLoggedIn(true);
      initAudio();
      cargarTodo();
      return;
    }

    try {
      // 1. Intentar inicio de sesión mediante el endpoint /api/auth/login de Render
      const authRes = await apiFetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginUser, usuario: loginUser, password: loginPass }),
      });

      if (authRes.ok) {
        const authData = await authRes.json();
        const userObj = authData.usuario || authData.user || authData;
        if (userObj && !authData.error) {
          setCurrentUser(userObj);
          setIsLoggedIn(true);
          initAudio();
          cargarTodo();
          return;
        }
      }

      // 2. Si /api/auth/login no autentica, verificar en el staff (/api/credenciales)
      const res = await apiFetch('/api/credenciales');
      const creds: Credencial[] = await res.json();
      const encontrado = creds.find(
        (c) => (c.usuario === loginUser || (c as any).email === loginUser) && (c.password === loginPass || (c as any).pass === loginPass)
      );
      if (encontrado) {
        setCurrentUser(encontrado);
        setIsLoggedIn(true);
        initAudio();
        cargarTodo();
      } else {
        alert('Credenciales incorrectas');
      }
    } catch (e) {
      alert('Error de conexión con el servidor');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    if (audioIntervalRef.current) {
      clearInterval(audioIntervalRef.current);
      audioIntervalRef.current = null;
    }
    if (html5QrCodeRef.current) {
      try {
        html5QrCodeRef.current.stop();
      } catch (err) {}
    }
  };

  const [descargandoZip, setDescargandoZip] = useState(false);

  const handleDescargarZip = async (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    if (descargandoZip) return;
    setDescargandoZip(true);
    try {
      const response = await fetch('/api/download-zip');
      if (!response.ok) {
        throw new Error('No se pudo generar el archivo ZIP');
      }
      const blob = await response.blob();
      const zipBlob = new Blob([blob], { type: 'application/octet-stream' });
      const url = window.URL.createObjectURL(zipBlob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'viajes-perdomo-proyecto.zip');
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        window.URL.revokeObjectURL(url);
        document.body.removeChild(link);
      }, 100);
    } catch (err: any) {
      alert('Error al descargar el archivo ZIP: ' + (err.message || 'Error de red'));
    } finally {
      setDescargandoZip(false);
    }
  };

  // Rutas: Orígenes y Destinos
  const agregarOrigen = async () => {
    const val = nuevoOrigen.trim();
    if (!val) return;
    await fetch('/api/origenes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre: val }),
    });
    setNuevoOrigen('');
    cargarTodo();
  };

  const agregarDestino = async () => {
    const val = nuevoDestino.trim();
    if (!val) return;
    await fetch('/api/destinos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre: val }),
    });
    setNuevoDestino('');
    cargarTodo();
  };

  const eliminarOrigen = async (nombre: string) => {
    const guaguasAfectadas = guaguas.filter((g) => g.origen === nombre);
    if (guaguasAfectadas.length === 0) {
      if (confirm(`¿Eliminar el origen "${nombre}"?`)) {
        await fetch(`/api/origenes/${encodeURIComponent(nombre)}`, { method: 'DELETE' });
        cargarTodo();
      }
      return;
    }

    const reservasAfectadas = reservas.filter((r) => {
      const g = guaguasAfectadas.find((x) => x.id === r.guaguaId);
      return g && r.estado !== 'cancelada' && r.estado !== 'cancelada_admin';
    });

    let msg = `El origen "${nombre}" está en uso por las guaguas: ${guaguasAfectadas.map((g) => g.id).join(', ')}.`;
    if (reservasAfectadas.length > 0) {
      msg += `\n\n¡ALERTA! Hay ${reservasAfectadas.length} reservas activas para estas guaguas. Se cancelarán automáticamente.`;
    }
    msg += `\n\n¿Deseas eliminarlo de todos modos?`;

    if (confirm(msg)) {
      for (const r of reservasAfectadas) {
        await fetch(`/api/reservas/${r.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ estado: 'cancelada_admin' }),
        });
        await fetch('/api/notificaciones', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            tipo: 'reserva_afectada',
            mensaje: `Reserva ${r.codigo} cancelada por eliminación del origen "${nombre}".`,
            cliente: r.nombre,
            email: r.email,
            codigoReserva: r.codigo,
          }),
        });
      }
      await fetch(`/api/origenes/${encodeURIComponent(nombre)}`, { method: 'DELETE' });
      for (const g of guaguasAfectadas) {
        await fetch(`/api/guaguas/${g.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ origen: '' }),
        });
        await fetch('/api/notificaciones', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            tipo: 'alerta_critica',
            mensaje: `La guagua ${g.id} se quedó sin Origen porque se eliminó "${nombre}". Asigna uno nuevo.`,
            guaguaId: g.id,
            requiereAccion: true,
          }),
        });
      }
      cargarTodo();
    }
  };

  const eliminarDestino = async (nombre: string) => {
    const guaguasAfectadas = guaguas.filter((g) => g.destino === nombre);
    if (guaguasAfectadas.length === 0) {
      if (confirm(`¿Eliminar el destino "${nombre}"?`)) {
        await fetch(`/api/destinos/${encodeURIComponent(nombre)}`, { method: 'DELETE' });
        cargarTodo();
      }
      return;
    }

    const reservasAfectadas = reservas.filter((r) => {
      const g = guaguasAfectadas.find((x) => x.id === r.guaguaId);
      return g && r.estado !== 'cancelada' && r.estado !== 'cancelada_admin';
    });

    let msg = `El destino "${nombre}" está en uso por las guaguas: ${guaguasAfectadas.map((g) => g.id).join(', ')}.`;
    if (reservasAfectadas.length > 0) {
      msg += `\n\n¡ALERTA! Hay ${reservasAfectadas.length} reservas activas. Se cancelarán automáticamente.`;
    }
    msg += `\n\n¿Deseas eliminarlo de todos modos?`;

    if (confirm(msg)) {
      for (const r of reservasAfectadas) {
        await fetch(`/api/reservas/${r.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ estado: 'cancelada_admin' }),
        });
        await fetch('/api/notificaciones', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            tipo: 'reserva_afectada',
            mensaje: `Reserva ${r.codigo} cancelada por eliminación del destino "${nombre}".`,
            cliente: r.nombre,
            email: r.email,
            codigoReserva: r.codigo,
          }),
        });
      }
      await fetch(`/api/destinos/${encodeURIComponent(nombre)}`, { method: 'DELETE' });
      for (const g of guaguasAfectadas) {
        await fetch(`/api/guaguas/${g.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ destino: '' }),
        });
        await fetch('/api/notificaciones', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            tipo: 'alerta_critica',
            mensaje: `La guagua ${g.id} se quedó sin Destino porque se eliminó "${nombre}". Asigna uno nuevo.`,
            guaguaId: g.id,
            requiereAccion: true,
          }),
        });
      }
      cargarTodo();
    }
  };

  // Compresión de fotos
  const procesarImagen = (file: File, maxW: number, maxH: number): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          if (width > maxW) {
            height = height * (maxW / width);
            width = maxW;
          }
          if (height > maxH) {
            width = width * (maxH / height);
            height = maxH;
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            resolve(canvas.toDataURL('image/jpeg', 0.7));
          } else {
            resolve(e.target?.result as string);
          }
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const handleFotoGuagua = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    const base64 = await procesarImagen(e.target.files[0], 600, 400);
    setFotoGuaguaBase64(base64);
  };

  const handleFotoChofer = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    const base64 = await procesarImagen(e.target.files[0], 300, 300);
    setFotoChoferBase64(base64);
  };

  // Modales Guagua
  const abrirNuevaGuagua = () => {
    setGId('');
    setGPlaca('');
    setGOrigen(origenes[0] || '');
    setGDestino(destinos[0] || '');
    setGPrecio(1000);
    setGMoneda('CUP');
    setGSalida('08:00');
    setGDuracion(2);
    setGAsientos(40);
    setGEstado('funcionamiento');
    setGMotivoTaller('');
    setGTipoProgramacion('unico');
    setGFechasUnicas(new Date().toISOString().split('T')[0]);
    setGDiasRecurrentes([]);
    setFotoGuaguaBase64(null);
    setModalGuaguaOpen(true);
  };

  const abrirEditarGuagua = (g: Guagua) => {
    setGId(g.id);
    setGPlaca(g.id);
    setGOrigen(g.origen || '');
    setGDestino(g.destino || '');
    setGPrecio(g.precio || 0);
    setGMoneda(g.moneda || 'CUP');
    setGSalida(g.salida || '08:00');
    setGDuracion(g.duracion || 2);
    setGAsientos(g.asientos || 40);
    setGEstado(g.estado || 'funcionamiento');
    setGMotivoTaller(g.motivoTaller || '');
    setGTipoProgramacion('unico');
    setGFechasUnicas(g.fecha || '');
    setGDiasRecurrentes([]);
    setFotoGuaguaBase64(g.imagen || null);
    setModalGuaguaOpen(true);
  };

  const guardarGuagua = async () => {
    const placa = gPlaca.trim();
    if (!placa) return alert('La placa es obligatoria');

    if (gSalida && gDuracion > 0) {
      const [h, m] = gSalida.split(':').map(Number);
      const minutosSalida = h * 60 + m;
      const minutosFin = minutosSalida + gDuracion * 60;

      const choque = guaguas.find((g) => {
        if (g.id === gId) return false;
        if (g.id !== placa) return false;
        if (!g.salida || !g.duracion) return false;
        const [gh, gm] = g.salida.split(':').map(Number);
        const mSalidaG = gh * 60 + gm;
        const mFinG = mSalidaG + g.duracion * 60;
        return minutosSalida < mFinG && minutosFin > mSalidaG;
      });

      if (choque) {
        return alert(
          `❌ CONFLICTO DE HORARIO:\nLa guagua ${placa} ya tiene un viaje programado a las ${choque.salida}.\nNo puede iniciar otro a las ${gSalida}. Elige otra hora.`
        );
      }
    }

    let fechasAProgramar: string[] = [];
    if (gTipoProgramacion === 'unico') {
      const fechasTexto = gFechasUnicas.trim();
      if (fechasTexto) fechasAProgramar = fechasTexto.split(',').map((f) => f.trim());
    } else {
      if (gDiasRecurrentes.length === 0) return alert('Selecciona al menos un día de la semana.');
      const hoy = new Date();
      const fin = new Date();
      fin.setMonth(fin.getMonth() + 3);

      for (let d = new Date(hoy); d <= fin; d.setDate(d.getDate() + 1)) {
        if (gDiasRecurrentes.includes(d.getDay())) {
          fechasAProgramar.push(d.toISOString().split('T')[0]);
        }
      }
    }

    if (fechasAProgramar.length === 0) return alert('Debes especificar al menos una fecha.');

    const baseData = {
      id: placa,
      placa: placa,
      origen: gOrigen,
      destino: gDestino,
      precio: Number(gPrecio),
      moneda: gMoneda,
      salida: gSalida,
      duracion: Number(gDuracion),
      asientos: Number(gAsientos),
      estado: gEstado,
      motivoTaller: gMotivoTaller,
      imagen: fotoGuaguaBase64,
    };

    for (const f of fechasAProgramar) {
      const data = { ...baseData, fecha: f, asientosDisp: baseData.asientos };
      const method = gId ? 'PUT' : 'POST';
      const url = gId ? `/api/guaguas/${gId}` : '/api/guaguas';
      await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
    }

    setModalGuaguaOpen(false);
    cargarTodo();
  };

  const eliminarGuagua = async (id: string) => {
    const reservasActivas = reservas.filter(
      (r) => r.guaguaId === id && r.estado !== 'cancelada' && r.estado !== 'cancelada_admin'
    );

    if (reservasActivas.length > 0) {
      const msg = `¡ALERTA! La guagua ${id} tiene ${reservasActivas.length} reservas activas. Se cancelarán automáticamente.\n\n¿Estás seguro de eliminar de todos modos?`;
      if (confirm(msg)) {
        if (!confirm('⚠️ ÚLTIMA ADVERTENCIA: Esta acción es irreversible. ¿Confirmar eliminación?')) return;
        for (const r of reservasActivas) {
          await fetch(`/api/reservas/${r.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ estado: 'cancelada_admin' }),
          });
          await fetch('/api/notificaciones', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              tipo: 'reserva_afectada',
              mensaje: `Reserva ${r.codigo} cancelada por eliminación de la guagua ${id}.`,
              cliente: r.nombre,
              email: r.email,
              codigoReserva: r.codigo,
            }),
          });
        }
        await fetch(`/api/guaguas/${id}`, { method: 'DELETE' });
        cargarTodo();
      }
    } else {
      if (confirm(`¿Eliminar la guagua ${id}?`)) {
        await fetch(`/api/guaguas/${id}`, { method: 'DELETE' });
        cargarTodo();
      }
    }
  };

  // Modales Chofer
  const abrirNuevoChofer = () => {
    setCId('');
    setCNombre('');
    setCCarnet('');
    setCTelefono('');
    setCTipoAsignacion('ninguna');
    setCSelectRuta('');
    setCSelectGuaguaRuta('');
    setCSelectGuagua('');
    setCSelectRutaGuagua('');
    setCEstado('trabajando');
    setFotoChoferBase64(null);
    setModalChoferOpen(true);
  };

  const abrirEditarChofer = (c: Chofer) => {
    setCId(c.id);
    setCNombre(c.nombre);
    setCCarnet(c.carnet || '');
    setCTelefono(c.telefono || '');
    setCEstado(c.estado || 'trabajando');
    setFotoChoferBase64(c.foto || null);
    if (c.rutaAsignada && c.guaguaId) {
      setCTipoAsignacion('por_ruta');
      setCSelectRuta(c.rutaAsignada);
      setCSelectGuaguaRuta(c.guaguaId);
    } else if (c.guaguaId) {
      setCTipoAsignacion('por_guagua');
      setCSelectGuagua(c.guaguaId);
      setCSelectRutaGuagua(c.rutaAsignada || '');
    } else {
      setCTipoAsignacion('ninguna');
    }
    setModalChoferOpen(true);
  };

  const guardarChofer = async () => {
    const nombre = cNombre.trim();
    if (!nombre) return alert('El nombre es obligatorio');

    let guaguaId = '';
    let rutaAsignada = '';
    if (cTipoAsignacion === 'por_ruta') {
      rutaAsignada = cSelectRuta;
      guaguaId = cSelectGuaguaRuta;
    } else if (cTipoAsignacion === 'por_guagua') {
      guaguaId = cSelectGuagua;
      rutaAsignada = cSelectRutaGuagua;
    }

    const data = {
      nombre,
      carnet: cCarnet,
      telefono: cTelefono,
      guaguaId,
      rutaAsignada,
      estado: cEstado,
      foto: fotoChoferBase64,
    };

    const method = cId ? 'PUT' : 'POST';
    const url = cId ? `/api/choferes/${cId}` : '/api/choferes';
    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    setModalChoferOpen(false);
    cargarTodo();
  };

  const eliminarChofer = async (id: string) => {
    if (confirm('¿Eliminar este chofer?')) {
      await fetch(`/api/choferes/${id}`, { method: 'DELETE' });
      cargarTodo();
    }
  };

  // Modales Cliente
  const abrirNuevoCliente = () => {
    setCliId('');
    setCliNombre('');
    setCliEmail('');
    setCliPassword('');
    const primerGestor = gestores[0];
    setCliGestor(primerGestor ? primerGestor.usuario : '');
    setModalClienteOpen(true);
  };

  const abrirEditarCliente = (u: Usuario) => {
    setCliId(u.id);
    setCliNombre(u.nombre);
    setCliEmail(u.email);
    setCliPassword(u.password || '');
    setCliGestor(u.gestorCodigo || '');
    setModalClienteOpen(true);
  };

  const guardarCliente = async () => {
    if (!cliNombre || !cliEmail || !cliPassword) return alert('Completa todos los campos');
    const data = {
      nombre: cliNombre,
      email: cliEmail,
      password: cliPassword,
      gestorCodigo: cliGestor,
    };
    const method = cliId ? 'PUT' : 'POST';
    const url = cliId ? `/api/usuarios/${cliId}` : '/api/usuarios';
    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    setModalClienteOpen(false);
    cargarTodo();
  };

  const eliminarCliente = async (id: string) => {
    if (confirm('¿Seguro que deseas eliminar este cliente?')) {
      await fetch(`/api/usuarios/${id}`, { method: 'DELETE' });
      cargarTodo();
    }
  };

  // Modales Credenciales (Staff)
  const abrirNuevaCredencial = () => {
    setCredId('');
    setCredNombre('');
    setCredUsuario('');
    setCredPassword('');
    setCredRol('gestor');
    setModalCredencialOpen(true);
  };

  const abrirEditarCredencial = (c: Credencial) => {
    setCredId(c.id);
    setCredNombre(c.nombre);
    setCredUsuario(c.usuario);
    setCredPassword(c.password || '');
    setCredRol(c.rol);
    setModalCredencialOpen(true);
  };

  const guardarCredencial = async () => {
    if (!credNombre || !credUsuario || !credPassword) return alert('Completa todos los campos');
    const data = {
      nombre: credNombre,
      usuario: credUsuario,
      password: credPassword,
      rol: credRol,
    };
    const method = credId ? 'PUT' : 'POST';
    const url = credId ? `/api/credenciales/${credId}` : '/api/credenciales';
    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    setModalCredencialOpen(false);
    cargarTodo();
  };

  const eliminarCredencial = async (id: string) => {
    if (confirm('¿Seguro que deseas eliminar este usuario?')) {
      await fetch(`/api/credenciales/${id}`, { method: 'DELETE' });
      cargarTodo();
    }
  };

  // Notificaciones
  const marcarLeida = async (id: string) => {
    await fetch(`/api/notificaciones/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ leida: true }),
    });
    cargarTodo();
  };

  const marcarInformado = async (id: string) => {
    await fetch(`/api/notificaciones/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ informada: true, leida: true }),
    });
    cargarTodo();
  };

  const marcarTodasLeidas = async () => {
    for (const n of notificaciones.filter((x) => !x.leida && x.tipo !== 'alerta_critica')) {
      await fetch(`/api/notificaciones/${n.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ leida: true }),
      });
    }
    cargarTodo();
  };

  // Guardar Personalización PWA
  const guardarPwaConfig = async () => {
    await fetch('/api/config', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(pwaConfig),
    });
    alert('Configuración guardada.');
  };

  // Escáner QR
  const iniciarEscaner = () => {
    setQrResultado(null);
    if (typeof window.Html5Qrcode === 'undefined') {
      console.warn('Html5Qrcode no está cargado');
      return;
    }

    try {
      if (html5QrCodeRef.current) {
        html5QrCodeRef.current.stop().then(() => html5QrCodeRef.current?.clear()).catch(() => {});
      }
      const qrScanner = new window.Html5Qrcode('qr-reader');
      html5QrCodeRef.current = qrScanner;
      qrScanner
        .start(
          { facingMode: 'environment' },
          { fps: 10, qrbox: { width: 250, height: 250 } },
          (decodedText: string) => {
            qrScanner.stop().then(() => qrScanner.clear()).catch(() => {});
            buscarReservaPorCodigo(decodedText.trim().toUpperCase());
          },
          () => {}
        )
        .catch((err: any) => {
          console.warn('Cámara no iniciada:', err);
        });
    } catch (e) {
      console.warn('Error inicializando lector QR:', e);
    }
  };

  const descargarReservasOffline = async () => {
    try {
      const res = await fetch('/api/reservas');
      const data = await res.json();
      setReservas(data);
      localStorage.setItem('reservas_offline', JSON.stringify(data));
      alert(`✅ Reservas descargadas localmente para validación offline (${data.length} reservas).`);
    } catch (err) {
      alert('Error al descargar reservas.');
    }
  };

  const buscarReservaPorCodigo = async (codigo: string) => {
    let listaParaBuscar = reservas;
    try {
      const res = await fetch('/api/reservas');
      if (res.ok) {
        listaParaBuscar = await res.json();
        setReservas(listaParaBuscar);
        localStorage.setItem('reservas_offline', JSON.stringify(listaParaBuscar));
      }
    } catch (e) {
      listaParaBuscar = JSON.parse(localStorage.getItem('reservas_offline') || '[]');
    }

    const reserva = listaParaBuscar.find((r) => r.codigo === codigo);
    reproducirSonido();

    if (reserva) {
      if (
        reserva.estado === 'cancelada' ||
        reserva.estado === 'completada' ||
        reserva.estado === 'cancelada_admin'
      ) {
        setQrResultado({
          valida: false,
          reserva,
          mensaje: `RESERVA NO VÁLIDA (${reserva.estado})`,
        });
      } else {
        setQrResultado({
          valida: true,
          reserva,
          mensaje: 'RESERVA VÁLIDA',
        });
      }
    } else {
      setQrResultado({
        valida: false,
        mensaje: `No existe reserva con el código: ${codigo}`,
      });
    }
  };

  const completarReservaEscaneada = async () => {
    if (!qrResultado?.reserva) return;
    try {
      await fetch(`/api/reservas/${qrResultado.reserva.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ estado: 'completada' }),
      });
      alert('✅ Reserva Completada.');
      setQrResultado(null);
      cargarTodo();
      setTimeout(iniciarEscaner, 500);
    } catch (error) {
      alert('⚠️ Sin conexión. No se pudo completar en el servidor.');
    }
  };

  // Efecto cuando cambia la vista activa a 'escaner'
  useEffect(() => {
    if (activeView === 'escaner') {
      const timer = setTimeout(iniciarEscaner, 300);
      return () => {
        clearTimeout(timer);
        if (html5QrCodeRef.current) {
          try {
            html5QrCodeRef.current.stop();
          } catch (e) {}
        }
      };
    }
  }, [activeView]);

  // Cálculos de Guaguas filtradas
  const guaguasFiltradas = guaguas.filter((g) => {
    if (filtroEstadoGuagua && g.estado !== filtroEstadoGuagua) return false;
    if (filtroChoferGuagua === 'sin_chofer') {
      const guaguasConChofer = choferes.filter((c) => c.guaguaId).map((c) => c.guaguaId);
      if (guaguasConChofer.includes(g.id)) return false;
    }
    if (filtroRutaGuagua === 'sin_origen' && g.origen) return false;
    if (filtroRutaGuagua === 'sin_destino' && g.destino) return false;
    if (filtroRutaGuagua === 'sin_ambos' && (g.origen || g.destino)) return false;
    if (filtroRutaGuagua === 'completa' && (!g.origen || !g.destino)) return false;
    if (filtroFechaGuagua && g.fecha !== filtroFechaGuagua) return false;
    return true;
  });

  // Cálculos de Reservas filtradas
  const reservasFiltradas = reservas.filter((r) => {
    if (filtroFechaReserva && r.fechaViaje !== filtroFechaReserva) return false;
    return true;
  });

  // Notificaciones no leídas
  const notificacionesNoLeidas = notificaciones.filter((n) => !n.leida);

  // Listas auxiliares para selects dinámicos
  const rutasUnicas = Array.from(
    new Set(guaguas.filter((g) => g.origen && g.destino).map((g) => `${g.origen} → ${g.destino}`))
  );
  const placasUnicas = Array.from(new Set(guaguas.map((g) => g.id)));

  // Guaguas según ruta seleccionada en modal chofer
  const guaguasDeRutaSeleccionada = cSelectRuta
    ? guaguas.filter((g) => `${g.origen} → ${g.destino}` === cSelectRuta)
    : [];

  // Rutas según guagua seleccionada en modal chofer
  const rutasDeGuaguaSeleccionada = cSelectGuagua
    ? Array.from(
        new Set(
          guaguas
            .filter((g) => g.id === cSelectGuagua && g.origen && g.destino)
            .map((g) => `${g.origen} → ${g.destino}`)
        )
      )
    : [];

  return (
    <>
      {/* PANTALLA DE LOGIN */}
      <div className={`login-screen ${isLoggedIn ? 'hidden' : ''}`} id="login-screen">
        <div className="login-card">
          <h2>🚌 Panel de Control</h2>
          <form onSubmit={handleLogin}>
            <div className="field">
              <label>Usuario</label>
              <input
                type="text"
                id="login-user"
                value={loginUser}
                onChange={(e) => setLoginUser(e.target.value)}
                required
              />
            </div>
            <div className="field">
              <label>Contraseña</label>
              <input
                type="password"
                id="login-pass"
                value={loginPass}
                onChange={(e) => setLoginPass(e.target.value)}
                required
              />
            </div>
            <button type="submit" className="btn-login" id="btn-login">
              Entrar
            </button>
          </form>
        </div>
      </div>

      {/* APLICACIÓN PRINCIPAL */}
      <div className={`app ${isLoggedIn ? 'visible' : ''}`} id="app">
        {/* SIDEBAR */}
        <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`} id="sidebar">
          <div className="sidebar-header">
            <strong>Viajes Perdomo</strong>
            <button className="btn-menu" id="btn-close-sidebar" onClick={() => setSidebarOpen(false)}>
              ✕
            </button>
          </div>
          <nav className="sidebar-nav">
            <button
              className={`nav-item ${activeView === 'dashboard' ? 'active' : ''}`}
              data-view="dashboard"
              onClick={() => {
                setActiveView('dashboard');
                setSidebarOpen(false);
              }}
            >
              📊 Dashboard
            </button>
            <button
              className={`nav-item ${activeView === 'estadisticas' ? 'active' : ''}`}
              data-view="estadisticas"
              id="nav-estadisticas"
              onClick={() => {
                setActiveView('estadisticas');
                setSidebarOpen(false);
              }}
            >
              📈 Estadísticas
            </button>
            <button
              className={`nav-item ${activeView === 'rutas' ? 'active' : ''}`}
              data-view="rutas"
              id="nav-rutas"
              onClick={() => {
                setActiveView('rutas');
                setSidebarOpen(false);
              }}
            >
              🛣️ Rutas
            </button>
            <button
              className={`nav-item ${activeView === 'guaguas' ? 'active' : ''}`}
              data-view="guaguas"
              id="nav-guaguas"
              onClick={() => {
                setActiveView('guaguas');
                setSidebarOpen(false);
              }}
            >
              🚌 Guaguas
            </button>
            <button
              className={`nav-item ${activeView === 'choferes' ? 'active' : ''}`}
              data-view="choferes"
              id="nav-choferes"
              onClick={() => {
                setActiveView('choferes');
                setSidebarOpen(false);
              }}
            >
              🧑‍✈️ Choferes
            </button>
            <button
              className={`nav-item ${activeView === 'reservas' ? 'active' : ''}`}
              data-view="reservas"
              id="nav-reservas"
              onClick={() => {
                setActiveView('reservas');
                setSidebarOpen(false);
              }}
            >
              🎫 Reservas
            </button>
            <button
              className={`nav-item ${activeView === 'clientes' ? 'active' : ''}`}
              data-view="clientes"
              id="nav-clientes"
              onClick={() => {
                setActiveView('clientes');
                setSidebarOpen(false);
              }}
            >
              👥 Clientes PWA
            </button>
            <button
              className={`nav-item ${activeView === 'credenciales' ? 'active' : ''}`}
              data-view="credenciales"
              id="nav-credenciales"
              onClick={() => {
                setActiveView('credenciales');
                setSidebarOpen(false);
              }}
            >
              🛡️ Credenciales
            </button>
            <button
              className={`nav-item ${activeView === 'notificaciones' ? 'active' : ''}`}
              data-view="notificaciones"
              id="nav-notificaciones"
              onClick={() => {
                setActiveView('notificaciones');
                setSidebarOpen(false);
              }}
            >
              🔔 Notificaciones{' '}
              {notificacionesNoLeidas.length > 0 && (
                <span
                  id="notif-badge"
                  style={{
                    background: 'var(--danger)',
                    color: 'white',
                    padding: '0.1rem 0.4rem',
                    borderRadius: '50%',
                    fontSize: '0.7rem',
                    display: 'inline-block',
                    marginLeft: '0.4rem',
                  }}
                >
                  {notificacionesNoLeidas.length}
                </span>
              )}
            </button>
            <button
              className={`nav-item ${activeView === 'personalizar' ? 'active' : ''}`}
              data-view="personalizar"
              id="nav-personalizar"
              onClick={() => {
                setActiveView('personalizar');
                setSidebarOpen(false);
              }}
            >
              🎨 Personalizar App
            </button>
            <button
              className={`nav-item ${activeView === 'valoraciones' ? 'active' : ''}`}
              data-view="valoraciones"
              id="nav-valoraciones"
              onClick={() => {
                setActiveView('valoraciones');
                setSidebarOpen(false);
              }}
            >
              ⭐ Valoraciones
            </button>
            <button
              className={`nav-item ${activeView === 'escaner' ? 'active' : ''}`}
              data-view="escaner"
              id="nav-escaner"
              onClick={() => {
                setActiveView('escaner');
                setSidebarOpen(false);
              }}
            >
              📷 Escanear QR
            </button>
            <button
              onClick={handleDescargarZip}
              className="nav-item"
              disabled={descargandoZip}
              style={{
                background: 'rgba(22, 163, 74, 0.2)',
                color: '#4ade80',
                marginTop: '0.5rem',
                border: '1px solid rgba(74, 222, 128, 0.3)',
                cursor: descargandoZip ? 'wait' : 'pointer',
                textAlign: 'left',
                width: '100%',
              }}
            >
              {descargandoZip ? '⏳ Generando ZIP...' : '📦 Descargar ZIP (GitHub)'}
            </button>
          </nav>
        </aside>

        <div
          className={`sidebar-overlay ${sidebarOpen ? 'open' : ''}`}
          id="sidebar-overlay"
          onClick={() => setSidebarOpen(false)}
        ></div>

        {/* TOPBAR */}
        <header className="topbar">
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <button className="btn-menu" id="btn-menu" onClick={() => setSidebarOpen(true)}>
              ☰
            </button>
            <strong id="topbar-title">
              {activeView === 'dashboard' && '📊 Dashboard'}
              {activeView === 'estadisticas' && '📈 Estadísticas'}
              {activeView === 'rutas' && '🛣️ Rutas'}
              {activeView === 'guaguas' && '🚌 Guaguas'}
              {activeView === 'choferes' && '🧑‍✈️ Choferes'}
              {activeView === 'reservas' && '🎫 Reservas'}
              {activeView === 'clientes' && '👥 Clientes PWA'}
              {activeView === 'credenciales' && '🛡️ Credenciales'}
              {activeView === 'notificaciones' && '🔔 Notificaciones'}
              {activeView === 'personalizar' && '🎨 Personalizar App'}
              {activeView === 'valoraciones' && '⭐ Valoraciones'}
              {activeView === 'escaner' && '📷 Escanear QR'}
            </strong>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
            <button
              onClick={handleDescargarZip}
              disabled={descargandoZip}
              className="btn-primary"
              style={{
                background: '#16a34a',
                color: 'white',
                fontSize: '0.85rem',
                padding: '0.4rem 0.8rem',
                borderRadius: '8px',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.3rem',
                fontWeight: 'bold',
                whiteSpace: 'nowrap',
                cursor: descargandoZip ? 'wait' : 'pointer',
                border: 'none',
              }}
              title="Descargar código fuente completo en archivo .ZIP para subir a GitHub"
            >
              {descargandoZip ? '⏳ Generando ZIP...' : '📦 Descargar ZIP (GitHub)'}
            </button>
            <button className="btn-secondary" id="btn-logout" onClick={handleLogout}>
              Salir
            </button>
          </div>
        </header>

        {/* BANNER FLOTANTE DE NOTIFICACIONES */}
        {notificacionesNoLeidas.length > 0 && (
          <div
            className="toast-banner"
            id="toast-banner"
            style={{ display: 'block' }}
            onClick={() => setActiveView('notificaciones')}
          >
            🔔 Tienes <strong id="toast-count">{notificacionesNoLeidas.length}</strong>{' '}
            notificaciones pendientes. Haz clic para verlas.
          </div>
        )}

        <main className="content">
          {/* DASHBOARD */}
          <section className={`view ${activeView === 'dashboard' ? 'active' : ''}`} id="view-dashboard">
            <h2>Resumen General</h2>
            <div className="stat-grid">
              <div className="item-card">
                <h3>Guaguas Activas</h3>
                <div id="stat-guaguas" style={{ fontSize: '2rem', fontWeight: 800 }}>
                  {estadisticas.guaguasActivas}
                </div>
              </div>
              <div className="item-card">
                <h3>Reservas Pendientes</h3>
                <div id="stat-reservas" style={{ fontSize: '2rem', fontWeight: 800 }}>
                  {estadisticas.reservasPendientes ?? estadisticas.pendientes}
                </div>
              </div>
              <div className="item-card">
                <h3>Ventas Totales</h3>
                <div style={{ fontSize: '2rem', fontWeight: 800, color: 'var(--primary)' }}>
                  {estadisticas.totalVendidos ?? 0}
                </div>
              </div>
              <div className="item-card">
                <h3>Ganancias (CUP)</h3>
                <div style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--success)' }}>
                  ${(estadisticas.dineroCUP ?? 0).toLocaleString()} CUP
                </div>
              </div>
              <div className="item-card">
                <h3>Ganancias (MLC)</h3>
                <div style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--accent)' }}>
                  ${(estadisticas.dineroMLC ?? 0).toLocaleString()} MLC
                </div>
              </div>
            </div>
          </section>

          {/* ESTADÍSTICAS */}
          <section className={`view ${activeView === 'estadisticas' ? 'active' : ''}`} id="view-estadisticas">
            <div className="view-header">
              <h2>Estadísticas del Servidor (Render)</h2>
              <button className="btn-primary" onClick={cargarTodo}>
                🔄 Actualizar Datos
              </button>
            </div>

            <div className="stat-grid" style={{ marginBottom: '1.5rem' }}>
              <div className="item-card" style={{ borderLeft: '5px solid var(--primary)' }}>
                <h3>Totales de Ventas</h3>
                <div style={{ fontSize: '2.2rem', fontWeight: 800, color: 'var(--primary)' }}>
                  {estadisticas.totalVendidos ?? 0}
                </div>
                <p style={{ fontSize: '0.85rem', color: 'var(--muted)', marginTop: '0.3rem' }}>
                  Total de boletos / reservas vendidas
                </p>
              </div>

              <div className="item-card" style={{ borderLeft: '5px solid var(--success)' }}>
                <h3>Ganancias en CUP</h3>
                <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--success)' }}>
                  ${(estadisticas.dineroCUP ?? 0).toLocaleString('es-CU')} CUP
                </div>
                <p style={{ fontSize: '0.85rem', color: 'var(--muted)', marginTop: '0.3rem' }}>
                  Monto acumulado en Pesos Cubanos
                </p>
              </div>

              <div className="item-card" style={{ borderLeft: '5px solid var(--accent)' }}>
                <h3>Ganancias en MLC</h3>
                <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--accent)' }}>
                  ${(estadisticas.dineroMLC ?? 0).toLocaleString('es-CU')} MLC
                </div>
                <p style={{ fontSize: '0.85rem', color: 'var(--muted)', marginTop: '0.3rem' }}>
                  Monto acumulado en MLC
                </p>
              </div>

              <div className="item-card" style={{ borderLeft: '5px solid #3b82f6' }}>
                <h3>Reservas Completadas</h3>
                <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#3b82f6' }}>
                  {estadisticas.completados ?? 0}
                </div>
                <p style={{ fontSize: '0.85rem', color: 'var(--muted)', marginTop: '0.3rem' }}>
                  Viajes finalizados con éxito
                </p>
              </div>

              <div className="item-card" style={{ borderLeft: '5px solid var(--warning)' }}>
                <h3>Reservas Pendientes</h3>
                <div style={{ fontSize: '2.2rem', fontWeight: 800, color: 'var(--warning)' }}>
                  {estadisticas.pendientes ?? 0}
                </div>
                <p style={{ fontSize: '0.85rem', color: 'var(--muted)', marginTop: '0.3rem' }}>
                  Pendientes de confirmación o abordaje
                </p>
              </div>

              <div className="item-card" style={{ borderLeft: '5px solid var(--danger)' }}>
                <h3>Cancelaciones por Clientes</h3>
                <div style={{ fontSize: '2.2rem', fontWeight: 800, color: 'var(--danger)' }}>
                  {estadisticas.cancelados ?? 0}
                </div>
                <p style={{ fontSize: '0.85rem', color: 'var(--muted)', marginTop: '0.3rem' }}>
                  Cancelaciones gestionadas por clientes
                </p>
              </div>

              <div className="item-card" style={{ borderLeft: '5px solid #991b1b' }}>
                <h3>Cancelaciones por Admin</h3>
                <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#991b1b' }}>
                  {estadisticas.canceladosAdmin ?? 0}
                </div>
                <p style={{ fontSize: '0.85rem', color: 'var(--muted)', marginTop: '0.3rem' }}>
                  Cancelaciones por cambios de flota/rutas
                </p>
              </div>
            </div>

            <div className="item-card" style={{ maxWidth: '800px' }}>
              <h3 style={{ marginBottom: '1rem' }}>Resumen de Métricas Financieras y de Operación</h3>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.95rem' }}>
                <tbody>
                  <tr style={{ borderBottom: '1px solid var(--border)' }}>
                    <td style={{ padding: '0.75rem 0', fontWeight: 600 }}>Total Boletos Vendidos:</td>
                    <td style={{ padding: '0.75rem 0', textAlign: 'right', fontWeight: 700 }}>{estadisticas.totalVendidos ?? 0}</td>
                  </tr>
                  <tr style={{ borderBottom: '1px solid var(--border)' }}>
                    <td style={{ padding: '0.75rem 0', fontWeight: 600 }}>Ingresos Totales (CUP):</td>
                    <td style={{ padding: '0.75rem 0', textAlign: 'right', fontWeight: 700, color: 'var(--success)' }}>${(estadisticas.dineroCUP ?? 0).toLocaleString('es-CU')} CUP</td>
                  </tr>
                  <tr style={{ borderBottom: '1px solid var(--border)' }}>
                    <td style={{ padding: '0.75rem 0', fontWeight: 600 }}>Ingresos Totales (MLC):</td>
                    <td style={{ padding: '0.75rem 0', textAlign: 'right', fontWeight: 700, color: 'var(--accent)' }}>${(estadisticas.dineroMLC ?? 0).toLocaleString('es-CU')} MLC</td>
                  </tr>
                  <tr style={{ borderBottom: '1px solid var(--border)' }}>
                    <td style={{ padding: '0.75rem 0', fontWeight: 600 }}>Total Cancelaciones:</td>
                    <td style={{ padding: '0.75rem 0', textAlign: 'right', fontWeight: 700, color: 'var(--danger)' }}>{(estadisticas.cancelados ?? 0) + (estadisticas.canceladosAdmin ?? 0)}</td>
                  </tr>
                  <tr>
                    <td style={{ padding: '0.75rem 0', fontWeight: 600 }}>Ruta API Servidor:</td>
                    <td style={{ padding: '0.75rem 0', textAlign: 'right', fontWeight: 600, color: 'var(--primary)' }}>GET /api/estadisticas (https://viajesperdomos.onrender.com)</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* RUTAS */}
          <section className={`view ${activeView === 'rutas' ? 'active' : ''}`} id="view-rutas">
            <div className="view-header">
              <h2>Rutas (Orígenes y Destinos)</h2>
            </div>
            <div className="row-2" style={{ marginBottom: '1rem' }}>
              <div className="item-card">
                <h3>Orígenes</h3>
                <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.5rem' }}>
                  <input
                    type="text"
                    id="nuevo-origen-input"
                    placeholder="Nuevo Origen"
                    value={nuevoOrigen}
                    onChange={(e) => setNuevoOrigen(e.target.value)}
                    style={{ flex: 1, padding: '0.5rem', border: '1px solid var(--border)', borderRadius: '6px' }}
                  />
                  <button className="btn-primary" onClick={agregarOrigen}>
                    ➕
                  </button>
                </div>
                <div id="lista-origenes" style={{ marginTop: '1rem' }}>
                  {origenes.map((o) => (
                    <div
                      key={o}
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        padding: '0.5rem',
                        borderBottom: '1px solid var(--border)',
                      }}
                    >
                      {o}
                      <button
                        className="btn-danger"
                        style={{ padding: '0.2rem 0.5rem', fontSize: '0.7rem' }}
                        onClick={() => eliminarOrigen(o)}
                      >
                        🗑️
                      </button>
                    </div>
                  ))}
                  {origenes.length === 0 && (
                    <p style={{ color: 'var(--muted)', fontSize: '0.85rem' }}>No hay orígenes agregados.</p>
                  )}
                </div>
              </div>

              <div className="item-card">
                <h3>Destinos</h3>
                <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.5rem' }}>
                  <input
                    type="text"
                    id="nuevo-destino-input"
                    placeholder="Nuevo Destino"
                    value={nuevoDestino}
                    onChange={(e) => setNuevoDestino(e.target.value)}
                    style={{ flex: 1, padding: '0.5rem', border: '1px solid var(--border)', borderRadius: '6px' }}
                  />
                  <button className="btn-primary" onClick={agregarDestino}>
                    ➕
                  </button>
                </div>
                <div id="lista-destinos" style={{ marginTop: '1rem' }}>
                  {destinos.map((d) => (
                    <div
                      key={d}
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        padding: '0.5rem',
                        borderBottom: '1px solid var(--border)',
                      }}
                    >
                      {d}
                      <button
                        className="btn-danger"
                        style={{ padding: '0.2rem 0.5rem', fontSize: '0.7rem' }}
                        onClick={() => eliminarDestino(d)}
                      >
                        🗑️
                      </button>
                    </div>
                  ))}
                  {destinos.length === 0 && (
                    <p style={{ color: 'var(--muted)', fontSize: '0.85rem' }}>No hay destinos agregados.</p>
                  )}
                </div>
              </div>
            </div>
          </section>

          {/* GUAGUAS */}
          <section className={`view ${activeView === 'guaguas' ? 'active' : ''}`} id="view-guaguas">
            <div className="view-header">
              <h2>Flota de Guaguas</h2>
              <button className="btn-primary" id="btn-nueva-guagua" onClick={abrirNuevaGuagua}>
                ➕ Nueva Guagua
              </button>
            </div>

            <div className="filter-bar">
              <select
                id="filtro-estado-guagua"
                value={filtroEstadoGuagua}
                onChange={(e) => setFiltroEstadoGuagua(e.target.value)}
              >
                <option value="">Todos los Estados</option>
                <option value="funcionamiento">En Funcionamiento</option>
                <option value="taller">En el Taller</option>
                <option value="ruta">En Ruta</option>
              </select>
              <select
                id="filtro-chofer-guagua"
                value={filtroChoferGuagua}
                onChange={(e) => setFiltroChoferGuagua(e.target.value)}
              >
                <option value="">Todos los Choferes</option>
                <option value="sin_chofer">Sin Chofer Asignado</option>
              </select>
              <select
                id="filtro-ruta-guagua"
                value={filtroRutaGuagua}
                onChange={(e) => setFiltroRutaGuagua(e.target.value)}
              >
                <option value="">Todas las Rutas</option>
                <option value="sin_origen">Sin Origen</option>
                <option value="sin_destino">Sin Destino</option>
                <option value="sin_ambos">Sin Origen ni Destino</option>
                <option value="completa">Ruta Completa</option>
              </select>
              <input
                type="date"
                id="filtro-fecha-guagua"
                title="Filtrar por fecha"
                value={filtroFechaGuagua}
                onChange={(e) => setFiltroFechaGuagua(e.target.value)}
              />
              <button
                className="btn-secondary"
                onClick={() => {
                  setFiltroEstadoGuagua('');
                  setFiltroChoferGuagua('');
                  setFiltroRutaGuagua('');
                  setFiltroFechaGuagua('');
                }}
              >
                🔄 Limpiar Filtros
              </button>
            </div>

            <div className="list" id="lista-guaguas">
              {guaguasFiltradas.length === 0 ? (
                <p>No hay guaguas que coincidan con los filtros.</p>
              ) : (
                guaguasFiltradas.map((g) => {
                  let claseColor = 'card-guagua-naranja';
                  if (g.origen && g.destino) {
                    const tieneChofer = choferes.some((c) => c.guaguaId === g.id);
                    claseColor = tieneChofer ? 'card-guagua-verde' : 'card-guagua-amarilla';
                  }
                  if (!g.origen || !g.destino) claseColor = 'card-guagua-roja';

                  const choferAsignado = choferes.find((c) => c.guaguaId === g.id);

                  return (
                    <div key={g.id + (g.fecha || '')} className={`item-card ${claseColor}`}>
                      {g.imagen && (
                        <img
                          src={g.imagen}
                          alt={g.id}
                          style={{
                            width: '100%',
                            height: '100px',
                            objectFit: 'cover',
                            borderRadius: '8px',
                            marginBottom: '0.5rem',
                          }}
                        />
                      )}
                      <div className="item-header">
                        <div className="item-title">
                          🚌 {g.id} ({g.estado})
                        </div>
                        <div className="item-price">
                          {g.precio} {g.moneda}
                        </div>
                      </div>
                      <div style={{ fontSize: '0.9rem', color: 'var(--muted)' }}>
                        Ruta: {g.origen || '?'} → {g.destino || '?'}
                        <br />
                        Salida: {g.salida} | Dur: {g.duracion}h | Asientos: {g.asientosDisp ?? g.asientos}/{g.asientos}
                        <br />
                        Chofer: {choferAsignado ? choferAsignado.nombre : 'Sin asignar'}
                        <br />
                        {g.motivoTaller ? (
                          <>
                            Motivo Taller: {g.motivoTaller}
                            <br />
                          </>
                        ) : null}
                        {g.fecha ? `Fecha: ${g.fecha}` : ''}
                      </div>
                      <div className="item-actions">
                        <button className="btn-secondary" onClick={() => abrirEditarGuagua(g)}>
                          ✏️
                        </button>
                        <button className="btn-danger" onClick={() => eliminarGuagua(g.id)}>
                          🗑️
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </section>

          {/* CHOFERES */}
          <section className={`view ${activeView === 'choferes' ? 'active' : ''}`} id="view-choferes">
            <div className="view-header">
              <h2>Choferes</h2>
              <button className="btn-primary" id="btn-nuevo-chofer" onClick={abrirNuevoChofer}>
                ➕ Nuevo Chofer
              </button>
            </div>
            <div className="list" id="lista-choferes">
              {choferes.length === 0 ? (
                <p>No hay choferes registrados.</p>
              ) : (
                choferes.map((c) => {
                  let estadoMostrar = c.estado;
                  if (c.guaguaId) {
                    const guagua = guaguas.find(
                      (g) => g.id === c.guaguaId && g.fecha === new Date().toISOString().split('T')[0]
                    );
                    if (guagua && guagua.salida) {
                      const [h, m] = guagua.salida.split(':').map(Number);
                      const ahora = new Date();
                      const minutosAhora = ahora.getHours() * 60 + ahora.getMinutes();
                      const inicio = h * 60 + m;
                      const fin = inicio + guagua.duracion * 60;
                      if (minutosAhora >= inicio && minutosAhora <= fin) estadoMostrar = 'en_ruta';
                    }
                  }

                  const badgeClase =
                    estadoMostrar === 'trabajando'
                      ? 'confirmada'
                      : estadoMostrar === 'en_ruta'
                      ? 'completada'
                      : 'cancelada';

                  return (
                    <div key={c.id} className="item-card">
                      <img
                        src={c.foto || 'https://cdn-icons-png.flaticon.com/512/149/149071.png'}
                        alt={c.nombre}
                        className="chofer-foto"
                        style={{ margin: '0 auto 0.5rem' }}
                      />
                      <div className="item-header" style={{ justifyContent: 'center' }}>
                        <div className="item-title">{c.nombre}</div>
                      </div>
                      <div style={{ fontSize: '0.9rem', textAlign: 'center' }}>
                        Carnet: {c.carnet}
                        <br />
                        Tel: {c.telefono}
                        <br />
                        Guagua: {c.guaguaId || 'Ninguna'}
                        <br />
                        Ruta: {c.rutaAsignada || 'Ninguna'}
                        <br />
                        <span className={`estado ${badgeClase}`}>{estadoMostrar.toUpperCase()}</span>
                      </div>
                      <div className="item-actions">
                        <button className="btn-secondary" onClick={() => abrirEditarChofer(c)}>
                          ✏️
                        </button>
                        <button className="btn-danger" onClick={() => eliminarChofer(c.id)}>
                          🗑️
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </section>

          {/* RESERVAS */}
          <section className={`view ${activeView === 'reservas' ? 'active' : ''}`} id="view-reservas">
            <div className="view-header">
              <h2>Reservas</h2>
            </div>
            <div className="filter-bar">
              <input
                type="date"
                id="filtro-fecha-reserva"
                value={filtroFechaReserva}
                onChange={(e) => setFiltroFechaReserva(e.target.value)}
              />
              <button className="btn-secondary" onClick={() => setFiltroFechaReserva('')}>
                🔄 Limpiar Filtro
              </button>
            </div>
            <div className="list" id="lista-reservas">
              {reservasFiltradas.length === 0 ? (
                <p>No hay reservas registradas.</p>
              ) : (
                reservasFiltradas.map((r) => {
                  const g = guaguas.find((x) => x.id === r.guaguaId);
                  return (
                    <div key={r.id} className="item-card">
                      <div className="item-header">
                        <div className="item-title">{r.nombre}</div>
                        <span className={`estado ${r.estado}`}>{r.estado}</span>
                      </div>
                      <div style={{ fontSize: '0.9rem' }}>
                        <strong>Guagua:</strong> {g ? g.id : 'Desconocida'} | <strong>Ruta:</strong>{' '}
                        {g ? `${g.origen} → ${g.destino}` : '?'}
                        <br />
                        Código: {r.codigo} | Fecha: {r.fechaViaje}
                        <br />
                        Total: {r.total} {r.moneda} | Gestor: {r.gestorCodigo || 'N/A'}
                      </div>
                      <div className="item-actions">
                        <button
                          className="btn-danger"
                          onClick={async () => {
                            if (confirm('¿Eliminar esta reserva?')) {
                              await fetch(`/api/reservas/${r.id}`, { method: 'DELETE' });
                              cargarTodo();
                            }
                          }}
                        >
                          🗑️
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </section>

          {/* CLIENTES PWA */}
          <section className={`view ${activeView === 'clientes' ? 'active' : ''}`} id="view-clientes">
            <div className="view-header">
              <h2>Clientes PWA</h2>
              <button className="btn-primary" id="btn-nuevo-cliente" onClick={abrirNuevoCliente}>
                ➕ Crear Cliente
              </button>
            </div>
            <div className="list" id="lista-clientes">
              {usuarios.length === 0 ? (
                <p>No hay clientes registrados.</p>
              ) : (
                usuarios.map((u) => (
                  <div key={u.id} className="item-card">
                    <div className="item-header">
                      <div className="item-title">{u.nombre}</div>
                    </div>
                    <div style={{ fontSize: '0.9rem', color: 'var(--muted)' }}>
                      Email: <strong>{u.email}</strong>
                      <br />
                      Contraseña: {u.password}
                      <br />
                      Gestor: {u.gestorCodigo || 'N/A'}
                    </div>
                    <div className="item-actions">
                      <button className="btn-secondary" onClick={() => abrirEditarCliente(u)}>
                        ✏️ Editar
                      </button>
                      <button className="btn-danger" onClick={() => eliminarCliente(u.id)}>
                        🗑️
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>

          {/* CREDENCIALES (STAFF) */}
          <section className={`view ${activeView === 'credenciales' ? 'active' : ''}`} id="view-credenciales">
            <div className="view-header">
              <h2>Staff</h2>
              <button className="btn-primary" id="btn-nueva-credencial" onClick={abrirNuevaCredencial}>
                ➕ Nuevo Staff
              </button>
            </div>
            <div className="list" id="lista-credenciales">
              {credenciales.length === 0 ? (
                <p>No hay staff registrado.</p>
              ) : (
                credenciales.map((c) => (
                  <div key={c.id} className="item-card">
                    <div className="item-header">
                      <div className="item-title">{c.nombre}</div>
                      <span className="estado confirmada" style={{ background: 'var(--dark)', color: 'white' }}>
                        {c.rol.toUpperCase()}
                      </span>
                    </div>
                    <div style={{ fontSize: '0.9rem', color: 'var(--muted)' }}>
                      Usuario: <strong>{c.usuario}</strong>
                      <br />
                      Contraseña: {c.password}
                    </div>
                    <div className="item-actions">
                      <button className="btn-secondary" onClick={() => abrirEditarCredencial(c)}>
                        ✏️ Editar
                      </button>
                      <button className="btn-danger" onClick={() => eliminarCredencial(c.id)}>
                        🗑️
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>

          {/* NOTIFICACIONES */}
          <section
            className={`view ${activeView === 'notificaciones' ? 'active' : ''}`}
            id="view-notificaciones"
          >
            <div className="view-header">
              <h2>Centro de Notificaciones</h2>
              <button className="btn-secondary" onClick={marcarTodasLeidas}>
                Marcar todas como leídas
              </button>
            </div>
            <div className="list" id="lista-notificaciones">
              {notificaciones.length === 0 ? (
                <p>No hay notificaciones.</p>
              ) : (
                notificaciones.map((n) => {
                  const esCritica = n.tipo === 'alerta_critica';
                  const noLeida = !n.leida;

                  return (
                    <div
                      key={n.id}
                      className={`item-card notif-card ${noLeida ? 'no-leida' : ''} ${
                        esCritica ? 'critica' : ''
                      }`}
                    >
                      <div className="item-header">
                        <div className="item-title">
                          {esCritica ? '🚨 Alerta Crítica' : '🔔 Notificación'}
                        </div>
                        <span className={`estado ${noLeida ? 'pendiente' : 'confirmada'}`}>
                          {noLeida ? 'No Leída' : 'Leída'}
                        </span>
                      </div>
                      <p style={{ margin: '0.5rem 0', fontSize: '0.9rem' }}>{n.mensaje}</p>

                      {n.tipo === 'reserva_afectada' && n.cliente && (
                        <div className="cliente-afectado">
                          <span>
                            {n.cliente} ({n.email}) - Reserva {n.codigoReserva}
                          </span>
                          <button
                            className="btn-secondary"
                            style={{ padding: '0.2rem 0.5rem', fontSize: '0.7rem' }}
                            onClick={() => marcarInformado(n.id)}
                          >
                            {n.informada ? '✅ Informado' : 'Marcar Informado'}
                          </button>
                        </div>
                      )}

                      <div className="notif-actions">
                        {noLeida && (
                          <button className="btn-secondary" onClick={() => marcarLeida(n.id)}>
                            Marcar como leída
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </section>

          {/* PERSONALIZAR PWA */}
          <section className={`view ${activeView === 'personalizar' ? 'active' : ''}`} id="view-personalizar">
            <div className="view-header">
              <h2>Personalizar PWA</h2>
            </div>
            <div className="item-card" style={{ maxWidth: '600px', margin: '0 auto' }}>
              <div className="field">
                <label>Título Hero</label>
                <input
                  type="text"
                  id="pwa-hero-titulo"
                  value={pwaConfig.heroTitulo || ''}
                  onChange={(e) => setPwaConfig({ ...pwaConfig, heroTitulo: e.target.value })}
                />
              </div>
              <div className="field">
                <label>Subtítulo Hero</label>
                <input
                  type="text"
                  id="pwa-hero-subtitulo"
                  value={pwaConfig.heroSubtitulo || ''}
                  onChange={(e) => setPwaConfig({ ...pwaConfig, heroSubtitulo: e.target.value })}
                />
              </div>
              <button
                className="btn-primary"
                id="btn-guardar-pwa"
                style={{ width: '100%', marginTop: '1rem' }}
                onClick={guardarPwaConfig}
              >
                Guardar
              </button>
            </div>
          </section>

          {/* VALORACIONES */}
          <section className={`view ${activeView === 'valoraciones' ? 'active' : ''}`} id="view-valoraciones">
            <div className="view-header">
              <h2>Valoraciones de Clientes</h2>
            </div>
            <div className="list" id="lista-valoraciones">
              {valoraciones.length === 0 ? (
                <p>No hay valoraciones registradas en el servidor.</p>
              ) : (
                valoraciones.map((v) => (
                  <div key={v.id} className="item-card">
                    <div className="item-header">
                      <div className="item-title">{v.autor || 'Cliente Anónimo'}</div>
                      <span className="estado confirmada">{'⭐'.repeat(v.estrellas || 5)}</span>
                    </div>
                    <p style={{ margin: '0.5rem 0', fontSize: '0.95rem' }}>"{v.comentario}"</p>
                    <div style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>
                      {v.guaguaId ? `Guagua: ${v.guaguaId}` : ''} {v.fecha ? `| Fecha: ${v.fecha.split('T')[0]}` : ''}
                    </div>
                    <div className="item-actions">
                      <button
                        className="btn-danger"
                        style={{ padding: '0.3rem 0.6rem', fontSize: '0.8rem' }}
                        onClick={async () => {
                          if (confirm('¿Eliminar esta valoración?')) {
                            await fetch(`/api/valoraciones/${v.id}`, { method: 'DELETE' });
                            cargarTodo();
                          }
                        }}
                      >
                        🗑️ Eliminar
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>

          {/* ESCÁNER QR */}
          <section className={`view ${activeView === 'escaner' ? 'active' : ''}`} id="view-escaner">
            <div className="view-header">
              <h2>Escanear QR</h2>
              <button className="btn-secondary" onClick={descargarReservasOffline}>
                📥 Descargar Reservas (Offline)
              </button>
            </div>
            <div className="item-card" style={{ textAlign: 'center' }}>
              <div id="qr-reader" style={{ maxWidth: '400px', margin: '0 auto' }}></div>

              {/* Opción de ingreso manual de código para pruebas o fallas de cámara */}
              <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', maxWidth: '400px', margin: '1rem auto 0' }}>
                <input
                  type="text"
                  placeholder="O ingresa código de reserva (ej: VP-1234)"
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  style={{ flex: 1, padding: '0.6rem', border: '1px solid var(--border)', borderRadius: '8px' }}
                />
                <button
                  className="btn-primary"
                  onClick={() => {
                    if (manualCode.trim()) {
                      buscarReservaPorCodigo(manualCode.trim().toUpperCase());
                      setManualCode('');
                    }
                  }}
                >
                  Buscar
                </button>
              </div>

              {qrResultado && (
                <div
                  id="qr-resultado"
                  className="result-card"
                  style={{ display: 'block', marginTop: '1rem' }}
                >
                  {qrResultado.valida && qrResultado.reserva ? (
                    <>
                      <h3 style={{ color: 'var(--success)' }}>✅ RESERVA VÁLIDA</h3>
                      <p>
                        <strong>Cliente:</strong> {qrResultado.reserva.nombre}
                      </p>
                      <p>
                        <strong>Fecha:</strong> {qrResultado.reserva.fechaViaje}
                      </p>
                      <p>
                        <strong>Pasajeros:</strong> {qrResultado.reserva.cantidad}
                      </p>
                      <p>
                        <strong>Total:</strong> {qrResultado.reserva.total} {qrResultado.reserva.moneda}
                      </p>
                      <button
                        className="btn-primary"
                        style={{ marginTop: '1rem', width: '100%' }}
                        onClick={completarReservaEscaneada}
                      >
                        ✅ Marcar como Completada
                      </button>
                    </>
                  ) : (
                    <>
                      <h3 style={{ color: 'var(--danger)' }}>❌ {qrResultado.mensaje}</h3>
                      {qrResultado.reserva && <p>Cliente: {qrResultado.reserva.nombre}</p>}
                    </>
                  )}
                </div>
              )}
            </div>
          </section>
        </main>
      </div>

      {/* ========================================== */}
      {/* MODAL GUAGUA */}
      {/* ========================================== */}
      <div className={`modal-overlay ${modalGuaguaOpen ? 'open' : ''}`} id="modal-guagua">
        <div className="modal">
          <div className="modal-header">
            <h3 id="modal-titulo-guagua">{gId ? 'Editar Guagua' : 'Nueva Guagua'}</h3>
            <button className="btn-secondary" onClick={() => setModalGuaguaOpen(false)}>
              ✕
            </button>
          </div>
          <div className="modal-body">
            <input type="hidden" id="g-id" value={gId} />
            <div className="field">
              <label>Placa (ID Único)</label>
              <input
                type="text"
                id="g-placa"
                placeholder="Ej: A33"
                value={gPlaca}
                disabled={!!gId}
                onChange={(e) => setGPlaca(e.target.value)}
              />
            </div>

            <div className="field">
              <label>Foto de la Guagua (Opcional)</label>
              <input type="file" id="g-foto-file" accept="image/*" onChange={handleFotoGuagua} />
              {fotoGuaguaBase64 && (
                <div style={{ marginTop: '0.5rem' }}>
                  <img
                    id="g-foto-preview"
                    src={fotoGuaguaBase64}
                    alt="Preview"
                    style={{
                      width: '100%',
                      maxHeight: '120px',
                      objectFit: 'cover',
                      borderRadius: '8px',
                      display: 'block',
                    }}
                  />
                </div>
              )}
            </div>

            <div className="row-2">
              <div className="field">
                <label>Origen</label>
                <select id="g-origen" value={gOrigen} onChange={(e) => setGOrigen(e.target.value)}>
                  <option value="">-- Sin Origen --</option>
                  {origenes.map((o) => (
                    <option key={o} value={o}>
                      {o}
                    </option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Destino</label>
                <select id="g-destino" value={gDestino} onChange={(e) => setGDestino(e.target.value)}>
                  <option value="">-- Sin Destino --</option>
                  {destinos.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="row-2">
              <div className="field">
                <label>Precio</label>
                <input
                  type="number"
                  id="g-precio"
                  value={gPrecio}
                  onChange={(e) => setGPrecio(Number(e.target.value))}
                />
              </div>
              <div className="field">
                <label>Moneda</label>
                <select id="g-moneda" value={gMoneda} onChange={(e) => setGMoneda(e.target.value)}>
                  <option value="CUP">CUP</option>
                  <option value="MLC">MLC</option>
                </select>
              </div>
            </div>

            <div className="row-2">
              <div className="field">
                <label>Hora Salida</label>
                <input
                  type="time"
                  id="g-salida"
                  value={gSalida}
                  onChange={(e) => setGSalida(e.target.value)}
                />
              </div>
              <div className="field">
                <label>Duración (Horas)</label>
                <input
                  type="number"
                  id="g-duracion"
                  value={gDuracion}
                  step="0.5"
                  onChange={(e) => setGDuracion(Number(e.target.value))}
                />
              </div>
            </div>

            <div className="row-2">
              <div className="field">
                <label>Asientos</label>
                <input
                  type="number"
                  id="g-asientos"
                  value={gAsientos}
                  onChange={(e) => setGAsientos(Number(e.target.value))}
                />
              </div>
              <div className="field">
                <label>Estado</label>
                <select id="g-estado" value={gEstado} onChange={(e) => setGEstado(e.target.value)}>
                  <option value="funcionamiento">En Funcionamiento</option>
                  <option value="taller">En el Taller</option>
                  <option value="ruta">En Ruta (Auto)</option>
                </select>
              </div>
            </div>

            {gEstado === 'taller' && (
              <div className="field" id="g-motivo-taller-div">
                <label>Motivo del Taller</label>
                <input
                  type="text"
                  id="g-motivo-taller"
                  value={gMotivoTaller}
                  onChange={(e) => setGMotivoTaller(e.target.value)}
                />
              </div>
            )}

            <div className="field">
              <label>Tipo de Programación</label>
              <select
                id="g-tipo-programacion"
                value={gTipoProgramacion}
                onChange={(e) => setGTipoProgramacion(e.target.value as 'unico' | 'recurrente')}
              >
                <option value="unico">Día(s) Específico(s)</option>
                <option value="recurrente">Recurrente (Ej: Todos los Jueves)</option>
              </select>
            </div>

            {gTipoProgramacion === 'unico' ? (
              <div id="programacion-unica" className="field">
                <label>Fechas (Separadas por coma si son varias)</label>
                <input
                  type="text"
                  id="g-fechas-unicas"
                  placeholder="Ej: 2026-11-15, 2026-11-20"
                  value={gFechasUnicas}
                  onChange={(e) => setGFechasUnicas(e.target.value)}
                />
              </div>
            ) : (
              <div id="programacion-recurrente">
                <label style={{ fontSize: '0.8rem', fontWeight: 700 }}>Días de la semana</label>
                <div className="dias-semana">
                  {[
                    { label: 'Lunes', val: 1 },
                    { label: 'Martes', val: 2 },
                    { label: 'Miércoles', val: 3 },
                    { label: 'Jueves', val: 4 },
                    { label: 'Viernes', val: 5 },
                    { label: 'Sábado', val: 6 },
                    { label: 'Domingo', val: 0 },
                  ].map((dia) => (
                    <label key={dia.val} className="dia-check">
                      <input
                        type="checkbox"
                        value={dia.val}
                        className="dia-rec"
                        checked={gDiasRecurrentes.includes(dia.val)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setGDiasRecurrentes([...gDiasRecurrentes, dia.val]);
                          } else {
                            setGDiasRecurrentes(gDiasRecurrentes.filter((x) => x !== dia.val));
                          }
                        }}
                      />{' '}
                      {dia.label}
                    </label>
                  ))}
                </div>
                <p style={{ fontSize: '0.8rem', color: 'var(--muted)', marginTop: '0.5rem' }}>
                  Se generarán automáticamente los viajes para los próximos 3 meses.
                </p>
              </div>
            )}
          </div>
          <div className="modal-footer">
            <button className="btn-secondary" onClick={() => setModalGuaguaOpen(false)}>
              Cancelar
            </button>
            <button className="btn-primary" onClick={guardarGuagua}>
              Guardar
            </button>
          </div>
        </div>
      </div>

      {/* ========================================== */}
      {/* MODAL CHOFER */}
      {/* ========================================== */}
      <div className={`modal-overlay ${modalChoferOpen ? 'open' : ''}`} id="modal-chofer">
        <div className="modal">
          <div className="modal-header">
            <h3 id="modal-titulo-chofer">{cId ? 'Editar Chofer' : 'Nuevo Chofer'}</h3>
            <button className="btn-secondary" onClick={() => setModalChoferOpen(false)}>
              ✕
            </button>
          </div>
          <div className="modal-body">
            <input type="hidden" id="c-id-chofer" value={cId} />
            <div style={{ textAlign: 'center' }}>
              <img
                id="c-foto-preview"
                className="chofer-foto"
                src={fotoChoferBase64 || 'https://cdn-icons-png.flaticon.com/512/149/149071.png'}
                alt="Chofer"
                onClick={() => document.getElementById('c-foto-file')?.click()}
              />
              <input
                type="file"
                id="c-foto-file"
                accept="image/*"
                style={{ display: 'none' }}
                onChange={handleFotoChofer}
              />
              <p style={{ fontSize: '0.7rem', color: 'var(--muted)' }}>Toca la imagen para cambiarla</p>
            </div>
            <div className="field">
              <label>Nombre y Apellidos</label>
              <input
                type="text"
                id="c-nombre-chofer"
                value={cNombre}
                onChange={(e) => setCNombre(e.target.value)}
              />
            </div>
            <div className="field">
              <label>Carnet de Identidad</label>
              <input
                type="text"
                id="c-carnet"
                value={cCarnet}
                onChange={(e) => setCCarnet(e.target.value)}
              />
            </div>
            <div className="field">
              <label>Teléfono</label>
              <input
                type="tel"
                id="c-telefono"
                value={cTelefono}
                onChange={(e) => setCTelefono(e.target.value)}
              />
            </div>

            <div className="field">
              <label>Asignación de Trabajo</label>
              <select
                id="c-tipo-asignacion"
                value={cTipoAsignacion}
                onChange={(e) => setCTipoAsignacion(e.target.value)}
              >
                <option value="ninguna">Sin Asignación</option>
                <option value="por_ruta">Asignar primero una Ruta</option>
                <option value="por_guagua">Asignar primero una Guagua</option>
              </select>
            </div>

            {cTipoAsignacion === 'por_ruta' && (
              <div id="asignacion-por-ruta">
                <div className="field">
                  <label>Selecciona la Ruta</label>
                  <select
                    id="c-select-ruta"
                    value={cSelectRuta}
                    onChange={(e) => {
                      setCSelectRuta(e.target.value);
                      setCSelectGuaguaRuta('');
                    }}
                  >
                    <option value="">-- Seleccione Ruta --</option>
                    {rutasUnicas.map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="field">
                  <label>Guaguas que cubren esa Ruta</label>
                  <select
                    id="c-select-guagua-ruta"
                    value={cSelectGuaguaRuta}
                    onChange={(e) => setCSelectGuaguaRuta(e.target.value)}
                  >
                    <option value="">-- Seleccione Guagua --</option>
                    {guaguasDeRutaSeleccionada.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.id}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {cTipoAsignacion === 'por_guagua' && (
              <div id="asignacion-por-guagua">
                <div className="field">
                  <label>Selecciona la Guagua</label>
                  <select
                    id="c-select-guagua"
                    value={cSelectGuagua}
                    onChange={(e) => {
                      setCSelectGuagua(e.target.value);
                      setCSelectRutaGuagua('');
                    }}
                  >
                    <option value="">-- Seleccione Guagua --</option>
                    {placasUnicas.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="field">
                  <label>Rutas que cubre esa Guagua</label>
                  <select
                    id="c-select-ruta-guagua"
                    value={cSelectRutaGuagua}
                    onChange={(e) => setCSelectRutaGuagua(e.target.value)}
                  >
                    <option value="">-- Seleccione Ruta --</option>
                    {rutasDeGuaguaSeleccionada.map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            <div className="field">
              <label>Estado del Chofer</label>
              <select
                id="c-estado"
                value={cEstado}
                onChange={(e) => setCEstado(e.target.value as any)}
              >
                <option value="trabajando">Trabajando</option>
                <option value="descanso">Descanso</option>
                <option value="vacaciones">Vacaciones</option>
                <option value="enfermo">Enfermo</option>
                <option value="en_ruta">En Ruta (Auto)</option>
              </select>
            </div>
          </div>
          <div className="modal-footer">
            <button className="btn-secondary" onClick={() => setModalChoferOpen(false)}>
              Cancelar
            </button>
            <button className="btn-primary" onClick={guardarChofer}>
              Guardar
            </button>
          </div>
        </div>
      </div>

      {/* ========================================== */}
      {/* MODAL CLIENTE */}
      {/* ========================================== */}
      <div className={`modal-overlay ${modalClienteOpen ? 'open' : ''}`} id="modal-cliente">
        <div className="modal">
          <div className="modal-header">
            <h3 id="modal-cliente-titulo">{cliId ? 'Editar Cliente' : 'Crear Cliente'}</h3>
            <button className="btn-secondary" onClick={() => setModalClienteOpen(false)}>
              ✕
            </button>
          </div>
          <div className="modal-body">
            <input type="hidden" id="cli-id" value={cliId} />
            <div className="field">
              <label>Nombre Completo</label>
              <input
                type="text"
                id="cli-nombre"
                value={cliNombre}
                onChange={(e) => setCliNombre(e.target.value)}
              />
            </div>
            <div className="field">
              <label>Correo Electrónico</label>
              <input
                type="email"
                id="cli-email"
                value={cliEmail}
                onChange={(e) => setCliEmail(e.target.value)}
              />
            </div>
            <div className="field">
              <label>Contraseña</label>
              <input
                type="text"
                id="cli-password"
                value={cliPassword}
                onChange={(e) => setCliPassword(e.target.value)}
              />
            </div>
            <div className="field">
              <label>Gestor Asignado</label>
              <select
                id="cli-gestor"
                value={cliGestor}
                onChange={(e) => setCliGestor(e.target.value)}
              >
                <option value="">-- Seleccione un gestor --</option>
                {gestores.map((g) => (
                  <option key={g.id} value={g.usuario}>
                    {g.nombre} ({g.usuario})
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="modal-footer">
            <button className="btn-secondary" onClick={() => setModalClienteOpen(false)}>
              Cancelar
            </button>
            <button className="btn-primary" onClick={guardarCliente}>
              Guardar
            </button>
          </div>
        </div>
      </div>

      {/* ========================================== */}
      {/* MODAL CREDENCIAL (STAFF) */}
      {/* ========================================== */}
      <div className={`modal-overlay ${modalCredencialOpen ? 'open' : ''}`} id="modal-credencial">
        <div className="modal">
          <div className="modal-header">
            <h3 id="modal-credencial-titulo">{credId ? 'Editar Staff' : 'Nuevo Staff'}</h3>
            <button className="btn-secondary" onClick={() => setModalCredencialOpen(false)}>
              ✕
            </button>
          </div>
          <div className="modal-body">
            <input type="hidden" id="c-id" value={credId} />
            <div className="field">
              <label>Nombre Completo</label>
              <input
                type="text"
                id="c-nombre"
                value={credNombre}
                onChange={(e) => setCredNombre(e.target.value)}
              />
            </div>
            <div className="field">
              <label>Usuario</label>
              <input
                type="text"
                id="c-usuario"
                value={credUsuario}
                onChange={(e) => setCredUsuario(e.target.value)}
              />
            </div>
            <div className="field">
              <label>Contraseña</label>
              <input
                type="text"
                id="c-password"
                value={credPassword}
                onChange={(e) => setCredPassword(e.target.value)}
              />
            </div>
            <div className="field">
              <label>Rol</label>
              <select
                id="c-rol"
                value={credRol}
                onChange={(e) => setCredRol(e.target.value as 'gestor' | 'admin')}
              >
                <option value="gestor">Gestor</option>
                <option value="admin">Administrador</option>
              </select>
            </div>
          </div>
          <div className="modal-footer">
            <button className="btn-secondary" onClick={() => setModalCredencialOpen(false)}>
              Cancelar
            </button>
            <button className="btn-primary" onClick={guardarCredencial}>
              Guardar
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
